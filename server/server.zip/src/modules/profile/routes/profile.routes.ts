import { Router } from "express";
import {
  getMyProfile,
  updateMyProfile,
  getProfileByUserId,
} from "../controllers/profile.controller";
import { protect } from "../../auth/middlewares/auth.middleware";
import { UserRole } from "../../auth/types/auth.types";

const router = Router();

// All routes require Superadmin authentication
router.use(protect(UserRole.SUPERADMIN));

// Profile routes
router.get("/me", getMyProfile);
router.put("/me", updateMyProfile);
router.get("/:userId", getProfileByUserId);

export default router;
