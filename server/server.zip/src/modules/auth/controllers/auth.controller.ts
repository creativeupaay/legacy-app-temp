import { Request, Response } from "express";
import asyncHandler from "../../../utils/asyncHandler";
import AppError from "../../../utils/appError";
import AuthUser from "../models/authuser.model";
import {
  generateTokens,
  verifyRefreshToken,
  getAccessTokenCookieOptions,
  getRefreshTokenCookieOptions,
  getCookieNames,
  getRefreshTokenExpiry,
  generateAccessToken,
} from "../utils/jwt.utils";
import { ILoginRequest, ISignupRequest, UserRole } from "../types/auth.types";

/**
 * @desc    Signup user with role
 * @route   POST /api/v1/auth/signup
 * @access  Public
 */
export const signup = asyncHandler(async (req: Request, res: Response) => {
  const { email, password, role } = req.body as ISignupRequest;

  // Validate role
  if (!role || !Object.values(UserRole).includes(role)) {
    throw new AppError("Valid role is required", 400);
  }

  // Check if user already exists with same email and role
  const existingUser = await AuthUser.findOne({ email, role });
  if (existingUser) {
    throw new AppError("User with this email and role already exists", 409);
  }

  // Create new user
  const user = await AuthUser.create({
    email,
    password,
    role,
  });

  // Generate tokens
  const { accessToken, refreshToken } = generateTokens(
    user._id.toString(),
    role
  );

  // Store refresh token
  await AuthUser.findByIdAndUpdate(user._id, {
    $push: {
      refreshTokens: {
        token: refreshToken,
        expiresAt: getRefreshTokenExpiry(),
      },
    },
  });

  // Get cookie names for this role
  const cookieNames = getCookieNames(role);

  // Set cookies
  res.cookie(
    cookieNames.accessToken,
    accessToken,
    getAccessTokenCookieOptions(role)
  );
  res.cookie(
    cookieNames.refreshToken,
    refreshToken,
    getRefreshTokenCookieOptions(role)
  );

  res.status(201).json({
    success: true,
    message: "User registered successfully",
    data: {
      user: {
        id: user._id,
        email: user.email,
        role: user.role,
      },
    },
  });
});

/**
 * @desc    Login user with role
 * @route   POST /api/v1/auth/login
 * @access  Public
 */
export const login = asyncHandler(async (req: Request, res: Response) => {
  const { email, password, role } = req.body as ILoginRequest;

  // Validate role
  if (!role || !Object.values(UserRole).includes(role)) {
    throw new AppError("Valid role is required", 400);
  }

  // Find user by email and role with password
  const user = await AuthUser.findOne({ email, role }).select(
    "+password +refreshTokens"
  );

  if (!user) {
    throw new AppError("Invalid credentials", 401);
  }

  // Check if user is active
  if (!user.isActive) {
    throw new AppError("Account is deactivated. Please contact support.", 403);
  }

  // Verify password
  const isPasswordValid = await user.comparePassword(password);
  if (!isPasswordValid) {
    throw new AppError("Invalid credentials", 401);
  }

  // Generate tokens
  const { accessToken, refreshToken } = generateTokens(
    user._id.toString(),
    role
  );

  // Clean up expired refresh tokens and add new one
  const now = new Date();
  const validTokens = user.refreshTokens.filter((rt) => rt.expiresAt > now);

  await AuthUser.findByIdAndUpdate(user._id, {
    refreshTokens: [
      ...validTokens,
      {
        token: refreshToken,
        expiresAt: getRefreshTokenExpiry(),
      },
    ],
  });

  // Get cookie names for this role
  const cookieNames = getCookieNames(role);

  // Set cookies
  res.cookie(
    cookieNames.accessToken,
    accessToken,
    getAccessTokenCookieOptions(role)
  );
  res.cookie(
    cookieNames.refreshToken,
    refreshToken,
    getRefreshTokenCookieOptions(role)
  );

  res.status(200).json({
    success: true,
    message: "Login successful",
    data: {
      user: {
        id: user._id,
        email: user.email,
        role: user.role,
      },
    },
  });
});

/**
 * @desc    Refresh access token
 * @route   POST /api/v1/auth/refresh
 * @access  Public (with refresh token cookie)
 */
export const refreshToken = asyncHandler(
  async (req: Request, res: Response) => {
    const { role } = req.body as { role: UserRole };

    // Validate role
    if (!role || !Object.values(UserRole).includes(role)) {
      throw new AppError("Valid role is required", 400);
    }

    const cookieNames = getCookieNames(role);
    const refreshTokenFromCookie = req.cookies[cookieNames.refreshToken];

    if (!refreshTokenFromCookie) {
      throw new AppError("Refresh token not found", 401);
    }

    // Verify refresh token
    const payload = verifyRefreshToken(refreshTokenFromCookie);
    if (!payload) {
      throw new AppError("Invalid or expired refresh token", 401);
    }

    // Verify role matches
    if (payload.role !== role) {
      throw new AppError("Token role mismatch", 401);
    }

    // Find user and verify refresh token exists
    const user = await AuthUser.findById(payload.userId).select(
      "+refreshTokens"
    );

    if (!user) {
      throw new AppError("User not found", 401);
    }

    if (!user.isActive) {
      throw new AppError("Account is deactivated", 403);
    }

    // Check if refresh token exists in user's tokens
    const tokenExists = user.refreshTokens.some(
      (rt) => rt.token === refreshTokenFromCookie && rt.expiresAt > new Date()
    );

    if (!tokenExists) {
      throw new AppError("Refresh token not found or expired", 401);
    }

    // Generate new access token
    const newAccessToken = generateAccessToken(user._id.toString(), role);

    // Set new access token cookie
    res.cookie(
      cookieNames.accessToken,
      newAccessToken,
      getAccessTokenCookieOptions(role)
    );

    res.status(200).json({
      success: true,
      message: "Token refreshed successfully",
    });
  }
);

/**
 * @desc    Logout user
 * @route   POST /api/v1/auth/logout
 * @access  Private
 */
export const logout = asyncHandler(async (req: Request, res: Response) => {
  const { role } = req.body as { role: UserRole };

  // Validate role
  if (!role || !Object.values(UserRole).includes(role)) {
    throw new AppError("Valid role is required", 400);
  }

  const cookieNames = getCookieNames(role);
  const refreshTokenFromCookie = req.cookies[cookieNames.refreshToken];

  // If user is authenticated, remove refresh token from database
  if (refreshTokenFromCookie && req.user) {
    await AuthUser.findByIdAndUpdate(req.user.userId, {
      $pull: {
        refreshTokens: { token: refreshTokenFromCookie },
      },
    });
  }

  // Clear cookies
  res.clearCookie(cookieNames.accessToken, { path: "/" });
  res.clearCookie(cookieNames.refreshToken, { path: "/" });

  res.status(200).json({
    success: true,
    message: "Logged out successfully",
  });
});

/**
 * @desc    Get current user
 * @route   GET /api/v1/auth/me
 * @access  Private
 */
export const getCurrentUser = asyncHandler(
  async (req: Request, res: Response) => {
    const user = await AuthUser.findById(req.user?.userId);

    if (!user) {
      throw new AppError("User not found", 404);
    }

    res.status(200).json({
      success: true,
      message: "User fetched successfully",
      data: {
        user: {
          id: user._id,
          email: user.email,
          role: user.role,
          isActive: user.isActive,
        },
      },
    });
  }
);
