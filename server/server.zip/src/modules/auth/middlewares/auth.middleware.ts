import { Request, Response, NextFunction } from "express";
import AppError from "../../../utils/appError";
import { verifyAccessToken, getCookieNames } from "../utils/jwt.utils";
import { UserRole, ITokenPayload } from "../types/auth.types";

// Extend Express Request to include user
declare global {
  namespace Express {
    interface Request {
      user?: ITokenPayload;
    }
  }
}

/**
 * Middleware to protect routes - requires valid access token
 * @param allowedRoles - Array of roles allowed to access the route
 */
export const protect = (...allowedRoles: UserRole[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    let token: string | undefined;
    let foundRole: UserRole | undefined;

    // Check for token in cookies based on allowed roles
    for (const role of allowedRoles) {
      const cookieNames = getCookieNames(role);
      const roleToken = req.cookies[cookieNames.accessToken];
      if (roleToken) {
        token = roleToken;
        foundRole = role;
        break;
      }
    }

    // Also check Authorization header as fallback
    if (!token && req.headers.authorization?.startsWith("Bearer ")) {
      token = req.headers.authorization.split(" ")[1];
    }

    if (!token) {
      throw new AppError("Not authorized - No token provided", 401);
    }

    // Verify token
    const decoded = verifyAccessToken(token);

    if (!decoded) {
      throw new AppError("Not authorized - Invalid or expired token", 401);
    }

    // Check if user's role is allowed
    if (allowedRoles.length > 0 && !allowedRoles.includes(decoded.role)) {
      throw new AppError(
        "Not authorized - Insufficient permissions",
        403
      );
    }

    // Attach user to request
    req.user = decoded;

    next();
  };
};

/**
 * Middleware to optionally authenticate user
 * Does not throw error if no token, just attaches user if valid token exists
 */
export const optionalAuth = (...roles: UserRole[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    let token: string | undefined;

    // Check for token in cookies based on roles
    const rolesToCheck = roles.length > 0 ? roles : Object.values(UserRole);

    for (const role of rolesToCheck) {
      const cookieNames = getCookieNames(role);
      const roleToken = req.cookies[cookieNames.accessToken];
      if (roleToken) {
        token = roleToken;
        break;
      }
    }

    // Also check Authorization header
    if (!token && req.headers.authorization?.startsWith("Bearer ")) {
      token = req.headers.authorization.split(" ")[1];
    }

    if (token) {
      const decoded = verifyAccessToken(token);
      if (decoded) {
        req.user = decoded;
      }
    }

    next();
  };
};

/**
 * Middleware to require specific role
 */
export const requireRole = (...roles: UserRole[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      throw new AppError("Not authorized", 401);
    }

    if (!roles.includes(req.user.role)) {
      throw new AppError("Not authorized - Insufficient permissions", 403);
    }

    next();
  };
};
