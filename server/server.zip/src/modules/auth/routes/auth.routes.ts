import { Router } from "express";
import {
  signup,
  login,
  refreshToken,
  logout,
  getCurrentUser,
} from "../controllers/auth.controller";
import { protect } from "../middlewares/auth.middleware";
import { UserRole } from "../types/auth.types";

const router = Router();

// Public routes
router.post("/signup", signup);
router.post("/login", login);
router.post("/refresh", refreshToken);

// Protected routes - allow all roles
router.post(
  "/logout",
  protect(UserRole.SUPERADMIN, UserRole.ADMIN, UserRole.USER),
  logout
);
router.get(
  "/me",
  protect(UserRole.SUPERADMIN, UserRole.ADMIN, UserRole.USER),
  getCurrentUser
);

export default router;
