import { Document, Types } from "mongoose";

export enum UserRole {
  SUPERADMIN = "superadmin",
  ADMIN = "admin",
  USER = "user",
}

export interface IAuthUser {
  email: string;
  password: string;
  role: UserRole;
  refreshTokens: IRefreshToken[];
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface IRefreshToken {
  token: string;
  createdAt: Date;
  expiresAt: Date;
}

export interface IAuthUserDocument extends IAuthUser, Document {
  _id: Types.ObjectId;
  comparePassword(candidatePassword: string): Promise<boolean>;
}

export interface ITokenPayload {
  userId: string;
  role: UserRole;
}

export interface IAuthTokens {
  accessToken: string;
  refreshToken: string;
}

export interface ILoginRequest {
  email: string;
  password: string;
  role: UserRole;
}

export interface ISignupRequest {
  email: string;
  password: string;
  role: UserRole;
}

export interface IRefreshTokenRequest {
  role: UserRole;
}

export interface IAuthResponse {
  success: boolean;
  message: string;
  data?: {
    user: {
      id: string;
      email: string;
      role: UserRole;
    };
  };
}

export interface ICurrentUserResponse {
  success: boolean;
  message: string;
  data?: {
    user: {
      id: string;
      email: string;
      role: UserRole;
      isActive: boolean;
    };
  };
}
