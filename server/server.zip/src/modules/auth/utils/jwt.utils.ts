import jwt from "jsonwebtoken";
import { env } from "../../../config/env.config";
import { ITokenPayload, UserRole, IAuthTokens } from "../types/auth.types";

const ACCESS_TOKEN_EXPIRY = "15m";
const REFRESH_TOKEN_EXPIRY = "7d";
const REFRESH_TOKEN_EXPIRY_MS = 7 * 24 * 60 * 60 * 1000; // 7 days in milliseconds

/**
 * Generate role-specific access token
 */
export const generateAccessToken = (
  userId: string,
  role: UserRole
): string => {
  const payload: ITokenPayload = { userId, role };
  return jwt.sign(payload, env.JWT_ACCESS_SECRET, {
    expiresIn: ACCESS_TOKEN_EXPIRY,
  });
};

/**
 * Generate role-specific refresh token
 */
export const generateRefreshToken = (
  userId: string,
  role: UserRole
): string => {
  const payload: ITokenPayload = { userId, role };
  return jwt.sign(payload, env.JWT_REFRESH_SECRET, {
    expiresIn: REFRESH_TOKEN_EXPIRY,
  });
};

/**
 * Generate both access and refresh tokens
 */
export const generateTokens = (
  userId: string,
  role: UserRole
): IAuthTokens => {
  return {
    accessToken: generateAccessToken(userId, role),
    refreshToken: generateRefreshToken(userId, role),
  };
};

/**
 * Verify access token
 */
export const verifyAccessToken = (token: string): ITokenPayload | null => {
  try {
    return jwt.verify(token, env.JWT_ACCESS_SECRET) as ITokenPayload;
  } catch {
    return null;
  }
};

/**
 * Verify refresh token
 */
export const verifyRefreshToken = (token: string): ITokenPayload | null => {
  try {
    return jwt.verify(token, env.JWT_REFRESH_SECRET) as ITokenPayload;
  } catch {
    return null;
  }
};

/**
 * Get refresh token expiry date
 */
export const getRefreshTokenExpiry = (): Date => {
  return new Date(Date.now() + REFRESH_TOKEN_EXPIRY_MS);
};

/**
 * Get cookie options for access token
 */
export const getAccessTokenCookieOptions = (role: UserRole) => ({
  httpOnly: true,
  secure: env.NODE_ENV === "production",
  sameSite: "lax" as const,
  maxAge: 15 * 60 * 1000, // 15 minutes
  path: "/",
});

/**
 * Get cookie options for refresh token
 */
export const getRefreshTokenCookieOptions = (role: UserRole) => ({
  httpOnly: true,
  secure: env.NODE_ENV === "production",
  sameSite: "lax" as const,
  maxAge: REFRESH_TOKEN_EXPIRY_MS,
  path: "/",
});

/**
 * Get role-specific cookie names
 */
export const getCookieNames = (role: UserRole) => ({
  accessToken: `${role}_access_token`,
  refreshToken: `${role}_refresh_token`,
});
