export const UserRole = {
  SUPERADMIN: "superadmin",
} as const;

export type UserRole = (typeof UserRole)[keyof typeof UserRole];

// Auth User interface
export interface IAuthUser {
  id: string;
  email: string;
  role: UserRole;
  isActive?: boolean;
}

// Login Request
export interface ILoginRequest {
  email: string;
  password: string;
  role: UserRole;
}

// Signup Request
export interface ISignupRequest {
  email: string;
  password: string;
  role: UserRole;
}

// Refresh Token Request
export interface IRefreshTokenRequest {
  role: UserRole;
}

// Logout Request
export interface ILogoutRequest {
  role: UserRole;
}

// Auth Response
export interface IAuthResponse {
  success: boolean;
  message: string;
  data?: {
    user: IAuthUser;
  };
}

// Current User Response
export interface ICurrentUserResponse {
  success: boolean;
  message: string;
  data?: {
    user: IAuthUser;
  };
}

// Auth State for Redux
export interface IAuthState {
  user: IAuthUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

// Route Types for AuthWrapper
export type RouteType = "public" | "private";

// AuthWrapper Props
export interface IAuthWrapperProps {
  children: React.ReactNode;
  routeType: RouteType;
  redirectPath: string;
}
