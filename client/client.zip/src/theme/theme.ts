import { createTheme } from '@mui/material/styles';


const baseTheme = createTheme({
  palette: {
    mode: 'dark',
    primary: {
      main: '#96FF43',
    },
  },
  typography: {
    fontFamily: '"Red Hat Display",  sans-serif',
    fontSize: 16,
  },
  shape: {
    borderRadius: 0,
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 0,
          textTransform: 'none',
          boxShadow: 'none',
          '&:hover': {
            boxShadow: 'none',
          },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 0,
          boxShadow: 'none',
        },
      },
    },
    MuiTextField: {
      defaultProps: {
        variant: 'standard',
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          borderRadius: 0,
        },
      },
    },
  },
});

export const theme = baseTheme;
