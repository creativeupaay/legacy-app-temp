import { Navigate, Route, Routes } from "react-router-dom";
import { AuthWrapper } from "@/features/auth";
import Login from "@/features/auth/components/Login";
import { DashboardLayout } from "@/components/layout";
import DashboardPage from "./dashboard/DashboardPage";
import UsersPage from "./users/UsersPage";
import ReportsPage from "./reports/ReportsPage";
import SettingsPage from "./settings/SettingsPage";

const SuperadminMain = () => {
  return (
    <Routes>
      {/* Public Routes */}
      <Route
        path="/login"
        element={
          <AuthWrapper routeType="public" redirectPath="/dashboard">
            <Login />
          </AuthWrapper>
        }
      />

      {/* Private Routes with Dashboard Layout */}
      <Route
        element={
          <AuthWrapper routeType="private" redirectPath="/login">
            <DashboardLayout />
          </AuthWrapper>
        }
      >
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/users" element={<UsersPage />} />
        <Route path="/reports" element={<ReportsPage />} />
        <Route path="/settings" element={<SettingsPage />} />
      </Route>

      {/* Default redirect */}
      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
};

export default SuperadminMain;
