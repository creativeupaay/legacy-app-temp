import { Typography, Box } from "@mui/material";

const UsersPage = () => {
  return (
    <Box>
      <Typography variant="h4">Users</Typography>
    </Box>
  );
};

export default UsersPage;
