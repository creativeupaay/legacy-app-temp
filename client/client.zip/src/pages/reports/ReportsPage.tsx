import { Typography, Box } from "@mui/material";

const ReportsPage = () => {
  return (
    <Box>
      <Typography variant="h4">Reports</Typography>
    </Box>
  );
};

export default ReportsPage;
