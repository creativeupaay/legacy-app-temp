import { Typography, Box } from "@mui/material";

const DashboardPage = () => {
  return (
    <Box>
      <Typography variant="h4">Dashboard</Typography>
    </Box>
  );
};

export default DashboardPage;
