import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import type {
  BaseQueryFn,
  FetchArgs,
  FetchBaseQueryError,
  FetchBaseQueryMeta,
} from "@reduxjs/toolkit/query";

const baseQuery = fetchBaseQuery({
  baseUrl: import.meta.env.VITE_API_URL,
  credentials: "include",
});

const baseQueryWithReauth: BaseQueryFn<
  string | FetchArgs,
  unknown,
  FetchBaseQueryError,
  object,
  FetchBaseQueryMeta
> = async (args, api, extraOptions) => {
  let result = await baseQuery(args, api, extraOptions);

  if (result.error && (result.error as FetchBaseQueryError).status === 401) {
    // Get current role from state to refresh the correct token
    const state = api.getState() as { auth?: { user?: { role?: string } } };
    const role = state.auth?.user?.role;

    if (role) {
      const refreshResult = await baseQuery(
        { url: "/auth/refresh", method: "POST", body: { role } },
        api,
        extraOptions
      );

      if (refreshResult.data) {
        // retry original request
        result = await baseQuery(args, api, extraOptions);
      } else {
        // Dispatch logout action - import dynamically to avoid circular dependency
        api.dispatch({ type: "auth/logout" });
      }
    } else {
      api.dispatch({ type: "auth/logout" });
    }
  }

  return result;
};

export const baseApi = createApi({
  reducerPath: "api",
  baseQuery: baseQueryWithReauth,
  tagTypes: ["Auth", "Profile"],
  endpoints: () => ({}),
});
