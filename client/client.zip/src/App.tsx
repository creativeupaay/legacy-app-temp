import { Route, BrowserRouter as Router, Routes } from "react-router-dom";
import "./App.css";
import SuperadminMain from "./pages/SuperadminMain";
import { Provider } from "react-redux";
import { store } from "./app/store";
import { ThemeProvider } from "./theme/ThemeProvider";

function App() {
  return (
    <Provider store={store}>
      <ThemeProvider>
        <Router>
          <Routes>
            <Route path="/*" element={<SuperadminMain />} />
          </Routes>
        </Router>
      </ThemeProvider>
    </Provider>
  );
}

export default App;
